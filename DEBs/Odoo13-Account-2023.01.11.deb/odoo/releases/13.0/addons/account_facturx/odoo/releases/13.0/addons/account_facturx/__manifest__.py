# -*- coding: utf-8 -*-
{
    'name' : 'Import Bills/Invoices From XML',
    'version' : '1.0',
    'category': 'Accounting/Accounting',
    'depends' : ['account'],
    'data': [
        'data/facturx_templates.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': True,
    'license': 'LGPL-3',
}
